# 实际截图索引

2026-11-05最近主控修复验收的真实生产浏览器截图；本轮只是整理，没有重新渲染或修饰页面。先看01/02/04/06/07，再看其他状态。

原图保留全页长度；部分截图包含受控测试输入与滚动范围。不能把截图当实时交互，也不能把reference误当当前应用。

| 文件 | 内容 |
|---|---|
| screenshots/01-home-1440.png | 首页、三个场景入口；未开始会话 |
| screenshots/02-discovery-1440.png | A的信号/趋势/事件列表 |
| screenshots/03-evidence-drawer-1440.png | 模拟证据抽屉 |
| screenshots/04-analysis-editor-en-1440.png | EN脚本编辑页；实际丢弃回归截图，恢复原稿 |
| screenshots/05-analysis-editor-ar-1440.png | AR派生版本编辑；含edited AR测试输入 |
| screenshots/06-storyboard-1440.png | 四镜头参考图；Video deferred |
| screenshots/07-delivery-1440.png | 模拟文案交付页及记录；测试主题/地址 |
| screenshots/08-delivery-confirm-1440.png | 修复后已保存v2确认弹窗 |
| screenshots/09-replay-1440.png | 前两步回放模式 |
| screenshots/10-delivery-1366.png | 常见笔记本宽度交付页 |
| screenshots/11-analysis-mobile-390.png | 移动宽度AR编辑页 |
| screenshots/12-delivery-unsaved-1440.png | 未保存交付状态，确认操作禁用 |

当前产品截图取自最新修复后主控复跑，原路径见KIT_INDEX.json中sourcePath。reference/reference-1440x900.png是原HTML基准，不是待评产品。

optional/implementation为当前页面源码；只在需要核对数据展示时阅读，不执行。optional/scenarios为三个网页作者内容包与审稿说明，供核对故事、营销建议与UI呈现差距；并非完整运行发布目录。

ZIP内原HTML依赖的视频未附：属于原零售情报标杆参考录像，不是Lavish广告；本次不评视频制作。
