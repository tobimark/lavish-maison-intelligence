# SERENITY：一次制作连贯营销案例内容

请依次阅读本包PROMPT_SERENITY.md、PROMPT_CONNECTED_FLOW.md及docs/SOCIAL_MOCK_CONTRACT.md，再制作交付物。两份Prompt同时执行，不要拆成两轮。

目标：热点洞察→为什么推荐SERENITY→原图/主视觉/视频的创意演进→EN/AR社媒视频帖预览文案。外部能力全Mock，现有视频为Provided素材。

交付：原要求A1.1.0十JSON、真实媒体/字幕/审稿说明，以及独立presentation/scent-layering/1.1.0/campaign-presentation.json。不要把本项目下载的英文content-pack当输入场景更新包。

旧资料里仅以下载/邮件为主链终点的说明已由新CONNECTED_MARKETING_FLOW覆盖；素材事实、旧输入Schema仍保留。直接交完整可下载ZIP，无需编写应用代码或制作新片。
