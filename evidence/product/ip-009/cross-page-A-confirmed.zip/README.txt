LAVISH INTERACTIVE MOCK PRODUCT · CONTENT PACK

Campaign: A Gesture, Considered (scn-luxury-gifting.brief.main)
Version: usr.usr.campaign-edit:scn-luxury-gifting.brief.main:e1896c38cda535ab0cb8233eaadc9c41f1fefcb4be2679be4ad74ea42aae77bb.script.1 (saved, session usr.campaign-edit:scn-luxury-gifting.brief.main:e1896c38cda535ab0cb8233eaadc9c41f1fefcb4be2679be4ad74ea42aae77bb)
Language: EN
Confirmation at export: Confirmed current

Files:
- brief.json — campaign brief and analysis rationale
- script.json — exact exported script version content
- subtitles-en.vtt — subtitle cues for this version
- storyboard.html — offline static four-shot reference (not a video)
- 2 media file(s) under media/ — real approved product/logo images referenced by the shots
- README.txt
- EXPORT.json — export metadata and attachment manifest

No MP4, no poster, no rendered video and no email delivery is included.
This pack does not confirm or change the script; it is an immutable snapshot of the selected version.
MAISON INTELLIGENCE · Demo / Mock data