LAVISH CONTENT-ONLY DEMO PACK

This archive was generated locally by the MAISON INTELLIGENCE mock demo.
No email was sent to any recipient. All addresses use the reserved .invalid domain.
No MP4, poster or video download is included; video production is deferred.
Scenario: SERENITY — A Story in Layers (Scent Layering concept) (scn-scent-layering@1.1.0)
Script: EN scn-scent-layering.script.en-v2

Files:
- scent-layering-en-v2-script.json
- scent-layering-en-subtitles.vtt
- scent-layering-en-email.txt
- SIMULATED-DELIVERY.json
- README.txt

The script JSON and VTT are generated from the selected script version; editing another version does not change this pack.