LAVISH INTERACTIVE MOCK PRODUCT · CONTENT PACK

Campaign: SERENITY — A Story in Layers (scn-scent-layering.brief.main)
Version: usr.usr.campaign-edit:scn-scent-layering.brief.main:709abfdeb11f28a316ca6709c751f21cbcabdcb7cf30e4756418d9d8f46f854d.script.1 (saved, session usr.campaign-edit:scn-scent-layering.brief.main:709abfdeb11f28a316ca6709c751f21cbcabdcb7cf30e4756418d9d8f46f854d)
Language: AR
Confirmation at export: Draft / Not confirmed

Files:
- brief.json — campaign brief and analysis rationale
- script.json — exact exported script version content
- subtitles-ar.vtt — subtitle cues for this version
- storyboard.html — offline static four-shot reference (not a video)
- 3 media file(s) under media/ — real approved product/logo images referenced by the shots
- README.txt
- EXPORT.json — export metadata and attachment manifest

No MP4, no poster, no rendered video and no email delivery is included.
This pack does not confirm or change the script; it is an immutable snapshot of the selected version.
MAISON INTELLIGENCE · Demo / Mock data