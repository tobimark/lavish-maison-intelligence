LAVISH CONTENT-ONLY DEMO PACK

This archive was generated locally by the MAISON INTELLIGENCE mock demo.
No email was sent to any recipient. All addresses use the reserved .invalid domain.
No MP4, poster or video download is included; video production is deferred.
Scenario: The Art of Scent Layering (scn-scent-layering@1.0.0)
Script: EN usr.usr.session-1793862096013-k03ug8.script.1

Files:
- scent-layering-en-1-script.json
- scent-layering-en-subtitles.vtt
- scent-layering-en-email.txt
- SIMULATED-DELIVERY.json
- README.txt

The script JSON and VTT are generated from the selected script version; editing another version does not change this pack.